DELETE FROM searches;
INSERT INTO searches (user_id, name, type, data) VALUES (1, 'test', 1, 'a:2:{s:6:"fields";s:1:"*";s:6:"search";s:4:"bush";}');
