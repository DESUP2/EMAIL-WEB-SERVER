DELETE FROM users;
INSERT INTO users (user_id, username, mail_host) VALUES(1, 'test@example.com', 'localhost');
